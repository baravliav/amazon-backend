package com.example.productdetailsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductdetailsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
