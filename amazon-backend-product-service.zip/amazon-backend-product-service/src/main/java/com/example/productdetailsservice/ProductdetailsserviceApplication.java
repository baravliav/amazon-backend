package com.example.productdetailsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductdetailsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductdetailsserviceApplication.class, args);
	}

}
